This directory contains JDBC JAR files.
