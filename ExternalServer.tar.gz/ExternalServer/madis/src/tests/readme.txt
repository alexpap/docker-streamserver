This directory is for putting test files that are not needed to be versioned. Everything
here will be ignored by mercurial.