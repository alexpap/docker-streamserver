# setting for functions

# To add headers for specific domain for file function
# add  values at domainExtraHeaders dictionary
# e.g. domainExtraHeaders={'www.domain.gr':{'header':'value'}}

domainExtraHeaders={"Accept-Encoding": "gzip"}