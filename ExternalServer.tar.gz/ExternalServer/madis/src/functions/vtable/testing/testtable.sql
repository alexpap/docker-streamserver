create table table1 (a,b,c);
insert into table1 values('James',10,2);
insert into table1 values('Mark',7,3);
insert into table1 values('Lila',74,1);
