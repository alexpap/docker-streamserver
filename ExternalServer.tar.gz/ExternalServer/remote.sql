attach database 'uniondataset.db' as uniondataset;

create temp view read_stream as wcache
select *
from (newtimeslidingwindow timewindow:1 frequency:1 granularity:1 equivalence:floor
      select cast(strftime('%s', timestamp) as int) as epoch, timestamp, value
      from (file dialect:json 'http://127.0.0.1:8989/lala'));

create temp view stream_query as wcache
select wid, (cast(now() as float) - cast((max(epoch)) as float)) as delay, avg(value)
from read_stream
group by wid;

select rowid, delay from (rowidvt select delay - 2.0 as delay from stream_query) where rowid > 5 limit 10;

